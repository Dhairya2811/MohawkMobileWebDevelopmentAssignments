<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'WR2bCGS7fz[jH:nAvp<@VSsba4e?o`o0S6]9[Ds{2b78|R:FiSBJ]o:~xkEEoPDe' );
define( 'SECURE_AUTH_KEY',  'V@ihg[cS;(J!WCSC?lBc.8p}O3l45O1ch0+%F*DQ=R*V7aoRU36-uaecJ;lfWrV{' );
define( 'LOGGED_IN_KEY',    'wsK=qTKhuBb5O:LZ>`rs<RJVO3PBf{KP.WN$yGhuGNFE7XGk$i#7lkPA5t6{)6b/' );
define( 'NONCE_KEY',        'aw2c]3}#Q3cmF)]P )$];aC=*sb,+3vxPx$Lr*ncj5oq%f4Apl,bbviwTBB^%0V-' );
define( 'AUTH_SALT',        'jqsN+Yo?a34o+E>6DTlb16/<%{@l:UH0Cg!4/P<aqn_wHEQ2=)L|2IG`[J-T( k-' );
define( 'SECURE_AUTH_SALT', 'Z6{gM?Hmz./zsZaxdUOA?Oo*z5`/2&a1oh(~u~A]S1^Mi?WOf+sybkDFTvRX^pVh' );
define( 'LOGGED_IN_SALT',   'j%mz9)>x{J|Vd2 ymY(%&3{h,tr.zc/#*{$4.mg9sNe#5B}j_}-M#reI4q;_X,l*' );
define( 'NONCE_SALT',       '5<bz@*6cHWA%NQHf1WVj90H<X`oV^YX`]h3&Tn|Y][61=?m;tE(`35BLm;|z<d+C' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
